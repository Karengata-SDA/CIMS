<div class="col-md-8 col-md-offset-4 col-sm-12 col-sm-offset-0 col-lg-8 col-lg-offset-4">
                            <div class="rqst-cal">
                                <h3 itemprop="headline">request a call back.</h3>
                                <p itemprop="description">Would you like to speak to one of our financial advisers over the phone? Just submit your details and we'll be in touch shortly. You can also email us if you would prefer.</p>
                                <span color="red">I would like to discuss:</span>
                                
									<form name="htmlform" class="rqst-cal-frm rmv-ext3"  method="post" action="submit.php">
									<div id="mail-status"></div>
										<div class="row">

											<div class="col-md-6 col-sm-6 col-lg-6">
											    <!--label for="first_name">Name *</label-->
												<font color="red">Name *</font>
												<input class="rd2" type="text" name="userName"  placeholder="Name:">
											</div>
											<div class="col-md-6 col-sm-6 col-lg-6">
												<!--label for="email">Email Address *</label-->
												<font color="red">Email Address</font>
												<input class="rd2" type="text" name="userEmail"  placeholder="Email:">
											</div>
											<div class="col-md-6 col-sm-6 col-lg-6">
												<!--label for="telephone">Telephone Number</label-->
												<font color="red">Telephone Number</font>
												<input class="rd2" type="text" name="phone"  placeholder="Phone number:">
											</div>
											<div class="col-md-6 col-sm-6 col-lg-6" id="subject-info" class="info">
												<!--label for="telephone" color="red">Subject</label-->
												 <font color="red">Subject</font> 
												<div id="form_need" class="slc-wrp rd2" type="text" name="subject"  required="required" data-error="Please specify your need.">
												  <select  name="subject" id="subject" >
													<option value=""></option>
													<option type="text" name="subject" id="subject" value="Advisory Services Request">Advisory Services</option>
													<option type="text" name="subject" id="subject" value="Sales Services Request">Sales Services</option>
													<option type="text" name="subject" id="subject" value="Marketing Services Request">Marketing Services</option>
													<option type="text" name="subject" id="subject" value="Strategy Services Request">Strategy Services</option>
													<option type="text" name="subject" id="subject" value="Other">Other</option>
												 </select>
												</div>
											</div>
											
											 <div class="col-md-12 col-sm-12 col-lg-12">
												<!--label color="red"> Message</label> <span id="content-info" class="info"></span><br /-->
												<font color="red">Message</font>
												<input name="content" id="content" class="rd2"
													rows="3">
											</div>
												<!--div>
													<input type="submit" value="Send" class="btnAction" />
												</div-->

											
											
											<div class="col-md-6 col-sm-6 col-lg-6">
												<button type="submit" value="Submit" class="rd2 ylw-bg" >SUBMIT</button>
											</div>
										</div>
									</form>
								
									<div id="loader-icon" style="display: none;">
										<img src="LoaderIcon.gif" />
									</div>
								
                            </div>
                        </div>