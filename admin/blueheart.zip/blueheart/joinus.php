<!DOCTYPE html>
<html  >
<head>
  <!-- Site made with Mobirise Website Builder v4.9.6, https://BlueHeart.com -->
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="generator" content="Blueheart, BlueHeart.com">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
  <link rel="shortcut icon" href="assets/images/blueheartlogo-handsonly-122x125.png" type="image/x-icon">
  <meta name="description" content="Website Builder Description">
  
  <title>Join Us</title>
  <link rel="stylesheet" href="assets/web/assets/mobirise-icons/mobirise-icons.css">
  <link rel="stylesheet" href="assets/tether/tether.min.css">
  <link rel="stylesheet" href="assets/soundcloud-plugin/style.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-grid.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-reboot.min.css">
  <link rel="stylesheet" href="assets/dropdown/css/style.css">
  <link rel="stylesheet" href="assets/socicon/css/styles.css">
  <link rel="stylesheet" href="assets/animatecss/animate.min.css">
  <link rel="stylesheet" href="assets/theme/css/style.css">
  <link rel="stylesheet" href="assets/mobirise/css/mbr-additional.css" type="text/css">
  
  
  
</head>
<body>
  <section class="menu cid-qTkzRZLJNu" once="menu" id="menu1-21">

    

    <nav class="navbar navbar-expand beta-menu navbar-dropdown align-items-center navbar-fixed-top navbar-toggleable-sm bg-color transparent">
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <div class="hamburger">
                <span></span>
                <span></span>
                <span></span>
                <span></span>
            </div>
        </button>
        <div class="menu-logo">
            <div class="navbar-brand">
                <span class="navbar-logo">
                    <a href="https://www.bitraffic.co.ke/blueheart">
                         <img src="assets/images/blueheartlogo-handsonly-122x125.png" alt="Blue Heart" title="Blue Heart International" style="height: 3.8rem;">
                    </a>
                </span>
                <span class="navbar-caption-wrap"><a class="navbar-caption text-white display-4" href="#top">
                        BLUEHEART<br> International</a></span>
            </div>
        </div>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav nav-dropdown" data-app-modern-menu="true"><li class="nav-item dropdown open">
                    <a class="nav-link link text-white dropdown-toggle display-4" href="index.html#header1-4" data-toggle="dropdown-submenu" aria-expanded="true">
                        
                        About Us</a><div class="dropdown-menu"><a class="text-white dropdown-item display-4" href="team.html#team1-2y">Our Team</a><a class="text-white dropdown-item display-4" href="achievements.html#header2-1m">Our Achievement</a></div>
                </li>
                <li class="nav-item">
                    <a class="nav-link link text-white display-4" href="services.html#slider2-2b">
                        
                        Services</a>
                </li><li class="nav-item"><a class="nav-link link text-white display-4" href="index.html#gallery2-n">
                        
                        Products</a></li><li class="nav-item dropdown"><a class="nav-link link text-white dropdown-toggle display-4" href="awareness.html" data-toggle="dropdown-submenu" aria-expanded="false">Awareness</a><div class="dropdown-menu"><a class="text-white dropdown-item display-4" href="awareness.html">Press Release</a><a class="text-white dropdown-item display-4" href="awareness.html">Donate</a><a class="text-white dropdown-item display-4" href="downloads.html">Downloads</a></div></li><li class="nav-item dropdown"><a class="nav-link link text-white dropdown-toggle display-4" href="index.html#header15-m" data-toggle="dropdown-submenu" aria-expanded="false">
                        
                        Contacts</a><div class="dropdown-menu"><a class="text-white dropdown-item display-4" href="index.html#form3-k">Invite Us</a><a class="text-white dropdown-item display-4" href="report.html">Report</a><a class="text-white dropdown-item display-4" href="joinus.html">Join Us</a><a class="text-white dropdown-item display-4" href="index.html#header15-m">Give Comment</a></div></li></ul>
            <div class="navbar-buttons mbr-section-btn"><a class="btn btn-sm btn-primary display-4" href="report.html"><span class="mbri-target mbr-iconfont mbr-iconfont-btn"></span>Report</a></div>
        </div>
    </nav>
</section>

<section>


</section>

<section class="engine"><a href="https://mobirise.info/n">free simple site templates</a></section><section class="header15 cid-rnlaKiPYsT mbr-parallax-background" id="header15-23">

    

    <div class="mbr-overlay" style="opacity: 0.5; background-color: rgb(7, 59, 76);"></div>

    <div class="container align-right">
        <div class="row">

            <div class="mbr-white col-lg-8 col-md-7 content-container">
                <h1 class="mbr-section-title mbr-bold pb-3 mbr-fonts-style display-1">JOIN US</h1>
                <p class="mbr-text pb-3 mbr-fonts-style display-5">We are ever looking for skilled people who are willing to volunteer their time and effort to help us combat human trafficking, child abuse and violence.<br> 
<br>If you are interested in joining the Blueheart family, please fill in the form below and tell us who you are and your area of expertise and we will get in touch with you.&nbsp;</p>
            </div>



<div class="col-lg-4 col-md-5">
  <div class="form-container">
  <div class="media-container-column" >
                            <div class="rqst-cal">
                                
                                
                  <form name="htmlform" class="rqst-cal-frm rmv-ext3"  method="post" action="submit.php">
                  <div id="mail-status"></div>
                    <div class="row">

                      <div class="col-md-6 col-sm-6 col-lg-6">
                          <!--label for="first_name">Name *</label-->
                        <font color="red">Name *</font>
                        <input class="rd2" type="text" name="userName"  placeholder="Name:">
                      </div>
                      <div class="col-md-6 col-sm-6 col-lg-6">
                        <!--label for="email">Email Address *</label-->
                        <font color="red">Email Address</font>
                        <input class="rd2" type="text" name="userEmail"  placeholder="Email:">
                      </div>
                      <div class="col-md-6 col-sm-6 col-lg-6">
                        <!--label for="telephone">Telephone Number</label-->
                        <font color="red">Telephone Number</font>
                        <input class="rd2" type="text" name="phone"  placeholder="Phone number:">
                      </div>
                      <div class="col-md-6 col-sm-6 col-lg-6" id="subject-info" class="info">
                        <!--label for="telephone" color="red">Subject</label-->
                         <font color="red">Subject</font> 
                        <div id="form_need" class="slc-wrp rd2" type="text" name="subject"  required="required" data-error="Please specify your need.">
                          <select  name="subject" id="subject" >
                          <option value=""></option>
                          <option type="text" name="subject" id="subject" value="Advisory Services Request">Advisory Services</option>
                          <option type="text" name="subject" id="subject" value="Sales Services Request">Sales Services</option>
                          <option type="text" name="subject" id="subject" value="Marketing Services Request">Marketing Services</option>
                          <option type="text" name="subject" id="subject" value="Strategy Services Request">Strategy Services</option>
                          <option type="text" name="subject" id="subject" value="Other">Other</option>
                         </select>
                        </div>
                      </div>
                      
                       <div class="col-md-12 col-sm-12 col-lg-12">
                        <!--label color="red"> Message</label> <span id="content-info" class="info"></span><br /-->
                        <font color="red">Message</font>
                        <input name="content" id="content" class="rd2"
                          rows="3">
                      </div>
           <div class="col-md-6 col-sm-6 col-lg-6">
                        <button type="submit" value="Submit" class="rd2 ylw-bg" >SUBMIT</button>
                      </div>
                    </div>
                  </form>
                
                  <div id="loader-icon" style="display: none;">
                    <img src="LoaderIcon.gif" />
                  </div>
                
          </div>
          </div>
          </div>
  </div>





            <div class="col-lg-4 col-md-5">
                <div class="form-container">
                    <div class="media-container-column" data-form-type="formoid">
                        <!---Formbuilder Form--->
                        <form action="submit.php" method="POST" class="mbr-form form-with-styler" data-form-title="Form"><input type="hidden" name="email" data-form-email="true" value="">
                            <div class="row">
                                <div hidden="hidden" data-form-alert="" class="alert alert-success col-12">Thanks for filling out the form!</div>
                                <div hidden="hidden" data-form-alert-danger="" class="alert alert-danger col-12">
                                </div>
                            </div>
                            <div class="dragArea row">
                                <div class="col-md-12 form-group " data-for="userName">
                                    <input type="text" name="userName" placeholder="Name" data-form-field="Name" required="required" class="form-control px-3 display-7" id="name-header15-23">
                                </div>
                                <div class="col-md-12 form-group " data-for="userEmail">
                                    <input type="email" name="userEmail" placeholder="Email" data-form-field="Email" required="required" class="form-control px-3 display-7" id="email-header15-23">
                                </div>
                                <div data-for="phone" class="col-md-12 form-group ">
                                    <input type="tel" name="phone" placeholder="Phone" data-form-field="Phone" class="form-control px-3 display-7" id="phone-header15-23">
                                </div>
                                <div data-for="content" class="col-md-12 form-group ">
                                    <textarea name="content" placeholder="Message" data-form-field="Message" class="form-control px-3 display-7" id="message-header15-23"></textarea>
                                </div>
                                <div class="col-md-12 input-group-btn"><button type="submit" class="btn btn-form btn-primary display-4">SEND FORM</button></div>
                            </div>
                        </form--><!---Formbuilder Form--->
                    </div>
                </div>
            </div>
        </div>
    </div>
    
</section>



<section class="cid-rnlb7C7Mfg" id="footer1-24">

    

    

    <div class="container">
        <div class="media-container-row content text-white">
            <div class="col-12 col-md-3">
                <div class="media-wrap">
                    <a href="#top">
                        <img src="assets/images/blueheartlogo-white-192x103.png" alt="Mobirise" title="">
                    </a>
                </div>
            </div>
            <div class="col-12 col-md-3 mbr-fonts-style display-7">
                <h5 class="pb-3">
                    Address
                </h5>
                <p class="mbr-text">97500-00200, 
<br>Nairobi, Kenya.</p>
            </div>
            <div class="col-12 col-md-3 mbr-fonts-style display-7">
                <h5 class="pb-3">
                    Contacts
                </h5>
                <p class="mbr-text">Email: <br>info@blueheart-international.org<br> 
blueheart.africa@gmail.com<br>
<br>Phone:<br> +254 7 777 911 91</p>
            </div>
            <div class="col-12 col-md-3 mbr-fonts-style display-7">
                <h5 class="pb-3">
                    Links
                </h5>
                <p class="mbr-text">BlueHeart App&nbsp;<br><a class="text-primary" href="#bottom">Download for </a>Android&nbsp;<br><a class="text-primary" href="#bottom">Download for&nbsp;</a>Apple</p>
            </div>
        </div>
        <div class="footer-lower">
            <div class="media-container-row">
                <div class="col-sm-12">
                    <hr>
                </div>
            </div>
            <div class="media-container-row mbr-white">
                <div class="col-sm-6 copyright">
                    <p class="mbr-text mbr-fonts-style display-7">
                        © Copyright 2019 BlueHeart Intl.  |  Designed by the MobTribe
                    </p>
                </div>
                <div class="col-md-6">
                    <div class="social-list align-right">
                        <div class="soc-item">
                            <a href="#bottom" target="_blank">
                                <span class="mbr-iconfont mbr-iconfont-social socicon-twitter socicon"></span>
                            </a>
                        </div>
                        <div class="soc-item">
                            <a href="#bottom" target="_blank">
                                <span class="mbr-iconfont mbr-iconfont-social socicon-facebook socicon"></span>
                            </a>
                        </div>
                        <div class="soc-item">
                            <a href="#bottom" target="_blank">
                                <span class="mbr-iconfont mbr-iconfont-social socicon-youtube socicon"></span>
                            </a>
                        </div>
                        <div class="soc-item">
                            <a href="#bottom" target="_blank">
                                <span class="mbr-iconfont mbr-iconfont-social socicon-instagram socicon"></span>
                            </a>
                        </div>
                        
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


  <script src="assets/web/assets/jquery/jquery.min.js"></script>
  <script src="assets/popper/popper.min.js"></script>
  <script src="assets/tether/tether.min.js"></script>
  <script src="assets/bootstrap/js/bootstrap.min.js"></script>
  <script src="assets/dropdown/js/script.min.js"></script>
  <script src="assets/touchswipe/jquery.touch-swipe.min.js"></script>
  <script src="assets/viewportchecker/jquery.viewportchecker.js"></script>
  <script src="assets/parallax/jarallax.min.js"></script>
  <script src="assets/smoothscroll/smooth-scroll.js"></script>
  <script src="assets/theme/js/script.js"></script>
  <script src="assets/formoid/formoid.min.js"></script>
  
  
  <input name="animation" type="hidden">
   <div id="scrollToTop" class="scrollToTop mbr-arrow-up"><a style="text-align: center;"><i class="mbr-arrow-up-icon mbr-arrow-up-icon-cm cm-icon cm-icon-smallarrow-up"></i></a></div>
  </body>
</html>