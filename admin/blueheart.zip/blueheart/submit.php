<?php
require('phpmailer/class.phpmailer.php');
error_reporting(0);

$listSkills = $_POST["listSkills"];
$favouriteExperience = $_POST["favouriteExperience"];
$yourWhy = $_POST["yourWhy"];
$trainingBackground = $_POST["trainingBackground"];
$employmentBackground = $_POST["employmentBackground"];
$previousExperience = $_POST["previousExperience"];
$content = $_POST["content"];
$employed = $_POST["employed"];
$occupation = $_POST["occupation"];
$homeno = $_POST["homeno"];
$cellno = $_POST["cellno"];
$hoursperweek = $_POST["hoursperweek"];
$timeframe1 = $_POST["timeframe1"];
$timeframe2 = $_POST["timeframe2"];
$timeframe3 = $_POST["timeframe3"];
$timeframe4 = $_POST["timeframe4"];
$timeframe5 = $_POST["timeframe5"];
$timeframe6 = $_POST["timeframe6"];
$timeframe7 = $_POST["timeframe7"];
$phone = $_POST["phone"];
$userName = $_POST["userName"];
$userEmail = $_POST["userEmail"];
$subject = $_POST["subject"];

$mail = new PHPMailer();
$mail->IsSMTP();
$mail->SMTPDebug = 0;
$mail->SMTPAuth = TRUE;
$mail->SMTPSecure = "ssl";
//$mail->Port     = 587;
$mail->Port     = 465;  
$mail->Username = "info@egeza.co.ke";
$mail->Password = "tweecha1P.";
$mail->Host     = "mail.egeza.co.ke";
//$mail->Host     = "smtp.gmail.com";
$mail->Mailer   = "smtp";
$mail->SetFrom($_POST["userEmail"], $_POST["userName"]);
$mail->AddReplyTo($_POST["userEmail"], $_POST["phone"]);
$mail->AddAddress("info@egeza.co.ke");	
$mail->Subject = $_POST["subject"];
$mail->WordWrap   = 80;
//$mail->MsgHTML($_POST["content"]);
$mail->Body =   "
<br><b>Name:</b> " . $userName . "
<br><b>Email:</b> " . $userEmail . "
<br><b>Telephone:</b> " . $phone . "
<br><b>Position Volunteering For:</b> " . $subject . "
<br><b>Employed?:</b> " . $employed . "
<br><b>Occupation:</b> " . $occupation . "
<br><b>Home Number:</b> " . $homeno . "
<br><b>Cell Number:</b> " . $cellno . "
<br><b>Number of hours available to volunteer each week:</b> " . $hoursperweek . "
<br><b>Time frames available to volunteer each week:</b>

	<br>Sunday: " . $timeframe1 . "
	<br>Monday: " . $timeframe2 . "
	<br>Tuesday: " . $timeframe3 . "
	<br>Wednesday: " . $timeframe4 . "
	<br>Thursday: " . $timeframe5 . "
	<br>Friday: " . $timeframe6 . "
	<br>Saturday: " . $timeframe7 . "

<br><b>Previous Experience:</b> " . $previousExperience . "
<br><b>Employment Background:</b> " . $employmentBackground . "
<br><b>Training Background:</b> " . $trainingBackground . "	
<br><b>Reason for Applying:</b> " . $yourWhy . "
<br><b>List of qualifications, Skills or Talents applicant would bring to this position :</b> " . $listSkills . "
<br><b>Description of favourite Volunteer or Work Experience :</b> " . $favouriteExperience . "
	

	

<br><b>Query:</b> " . $content  ;



   

$mail->IsHTML(true);




/*if(!$mail->Send()) {
	echo "<p class='error'>Problem in Sending Mail.</p>";
} else {
	echo "<p class='success'>Contact Mail Sent.</p>";
}*/	
?>


<!DOCTYPE html>
<html  >
<head>
  <!-- Site made with Mobirise Website Builder v4.9.6, https://BlueHeart.com -->
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="generator" content="Blueheart, BlueHeart.com">
  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1">
  <link rel="shortcut icon" href="assets/images/blueheartlogo-handsonly-122x125.png" type="image/x-icon">
  <meta name="description" content="Website Builder Description">
  
  <title>Join Us</title>
  <link rel="stylesheet" href="assets/web/assets/mobirise-icons/mobirise-icons.css">
  <link rel="stylesheet" href="assets/tether/tether.min.css">
  <link rel="stylesheet" href="assets/soundcloud-plugin/style.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-grid.min.css">
  <link rel="stylesheet" href="assets/bootstrap/css/bootstrap-reboot.min.css">
  <link rel="stylesheet" href="assets/dropdown/css/style.css">
  <link rel="stylesheet" href="assets/socicon/css/styles.css">
  <link rel="stylesheet" href="assets/animatecss/animate.min.css">
  <link rel="stylesheet" href="assets/theme/css/style.css">
  <link rel="stylesheet" href="assets/mobirise/css/mbr-additional.css" type="text/css">


  <link rel="stylesheet" href="./style.css">

  <link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css'>
<!--link rel='stylesheet' href='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css'-->
  
  <style type="text/css">
      
      label, input {
    display: block;
}

label {
    margin-bottom: 20px;
}


 /* Style the form */
#regForm /*{
  background-color: #ffffff;
  margin: 100px auto;
  padding: 40px;
  width: 70%;
  min-width: 300px;
}/

/* Style the input fields */
/*input {
  padding: 10px;
  width: 100%;
  font-size: 17px;
  font-family: Raleway;
  border: 1px solid #aaaaaa;
}*/

/* Mark input boxes that gets an error on validation: */
input.invalid {
  background-color: #ffdddd;
}

/* Hide all steps by default: */
.tab {
  display: none;
}

/* Make circles that indicate the steps of the form: */
.step {
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbbbbb;
  border: none;
  border-radius: 50%;
  display: inline-block;
  opacity: 0.5;
}

/* Mark the active step: */
.step.active {
  opacity: 1;
}

/* Mark the steps that are finished and valid: */
.step.finish {
  background-color: #4CAF50;
} 
  </style>
  
  
</head>
<body>
  <section class="menu cid-qTkzRZLJNu" once="menu" id="menu1-21">

    

    <nav class="navbar navbar-expand beta-menu navbar-dropdown align-items-center navbar-fixed-top navbar-toggleable-sm bg-color transparent">
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <div class="hamburger">
                <span></span>
                <span></span>
                <span></span>
                <span></span>
            </div>
        </button>
        <div class="menu-logo">
            <div class="navbar-brand">
                <span class="navbar-logo">
                    <a href="https://www.bitraffic.co.ke/blueheart">
                         <img src="assets/images/blueheartlogo-handsonly-122x125.png" alt="Blue Heart" title="Blue Heart International" style="height: 3.8rem;">
                    </a>
                </span>
                <span class="navbar-caption-wrap"><a class="navbar-caption text-white display-4" href="#top">
                        BLUEHEART<br> International</a></span>
            </div>
        </div>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav nav-dropdown" data-app-modern-menu="true"><li class="nav-item dropdown open">
                    <a class="nav-link link text-white dropdown-toggle display-4" href="index.html#header1-4" data-toggle="dropdown-submenu" aria-expanded="true">
                        
                        About Us</a><div class="dropdown-menu"><a class="text-white dropdown-item display-4" href="team.html#team1-2y">Our Team</a><a class="text-white dropdown-item display-4" href="achievements.html#header2-1m">Our Achievement</a></div>
                </li>
                <li class="nav-item">
                    <a class="nav-link link text-white display-4" href="services.html#slider2-2b">
                        
                        Services</a>
                </li><li class="nav-item"><a class="nav-link link text-white display-4" href="index.html#gallery2-n">
                        
                        Products</a></li><li class="nav-item dropdown"><a class="nav-link link text-white dropdown-toggle display-4" href="awareness.html" data-toggle="dropdown-submenu" aria-expanded="false">Awareness</a><div class="dropdown-menu"><a class="text-white dropdown-item display-4" href="awareness.html">Press Release</a><a class="text-white dropdown-item display-4" href="awareness.html">Donate</a><a class="text-white dropdown-item display-4" href="downloads.html">Downloads</a></div></li><li class="nav-item dropdown"><a class="nav-link link text-white dropdown-toggle display-4" href="index.html#header15-m" data-toggle="dropdown-submenu" aria-expanded="false">
                        
                        Contacts</a><div class="dropdown-menu"><a class="text-white dropdown-item display-4" href="index.html#form3-k">Invite Us</a><a class="text-white dropdown-item display-4" href="report.html">Report</a><a class="text-white dropdown-item display-4" href="joinus.html">Join Us</a><a class="text-white dropdown-item display-4" href="index.html#header15-m">Give Comment</a></div></li></ul>
            <div class="navbar-buttons mbr-section-btn"><a class="btn btn-sm btn-primary display-4" href="report.html"><span class="mbri-target mbr-iconfont mbr-iconfont-btn"></span>Report</a></div>
        </div>
    </nav>
</section>

<section class="engine"><a href="https://mobirise.info/n">free simple site templates</a></section><section class="header15 cid-rnlaKiPYsT mbr-parallax-background" id="header15-23">

    

    <div class="mbr-overlay" style="opacity: 0.5; background-color: rgb(7, 59, 76);"></div>

    <div class="container align-center">
        <div class="row">
            <div class="mbr-white col-lg-12 col-md-7 content-container">
                <h1 class="mbr-section-title mbr-bold pb-3 mbr-fonts-style display-1">Thank You!</h1>
                <p class="mbr-text pb-3 mbr-fonts-style display-5">Thank you for expressing interest in supporting BlueHeart International.<br>
                </p>
            </div>
            

            <div class="col-lg-12 col-md-7">

            	 <div class="form-container " >
                    
                    <div class="media-container-column " >
                        <!---Formbuilder Form--->
                        <form id="regForm" action="submit.php" method="POST" class="mbr-form form-with-styler" data-form-title="Form" style="height: 100%;"><input type="hidden" name="email" data-form-email="true" value="">

                          <h1>Registration Response:</h1>
                        
                        <div class="col-lg-12 ">

                            <div class="row">
                                <div hidden="hidden" data-form-alert="" class="alert alert-success col-12" style="align-content: center;">Thanks for filling out the form!</div>
                                <div hidden="hidden" data-form-alert-danger="" class="alert alert-danger col-12">
                                </div>

                                <?php
								  if(!$mail->Send()) {
									echo "<p  class='alert alert-danger col-12'>Problem in Sending Mail.</p>";
								} else {
									echo "<p  class='alert alert-success col-12'>Contact Mail Sent.</p>";
								}	
								?>
                            </div>


		                    <div id="statusMessage"> 
		                        <?php
		                        if (! empty($message)) {
		                            ?>
		                            <p class='<?php echo $type; ?>Message'><?php echo $message; ?></p>
		                        <?php
		                        }
		                        ?>
		                    </div>
                    </div>

                         </form> 


                         <!--div class="col-md-12 input-group-btn"><button href="page9plain.php" type="submit" class="btn btn-form btn-primary display-4">Back to Contact-Us Page</button>
                                </div-->    

                    

                </div>

                <div class="navbar-buttons mbr-section-btn"><a class="btn btn-sm btn-primary display-4" href="page9plain.php"><span class="mbri-target mbr-iconfont mbr-iconfont-btn"></span>Back to Contact-Us Page</a></div>
            </div>

            

        </div>
    </div>
    </div>
    
</section>

<section class="cid-rnlb7C7Mfg" id="footer1-24">

    

    

    <div class="container">
        <div class="media-container-row content text-white">
            <div class="col-12 col-md-3">
                <div class="media-wrap">
                    <a href="#top">
                        <img src="assets/images/blueheartlogo-white-192x103.png" alt="Mobirise" title="">
                    </a>
                </div>
            </div>
            <div class="col-12 col-md-3 mbr-fonts-style display-7">
                <h5 class="pb-3">
                    Address
                </h5>
                <p class="mbr-text">97500-00200, 
<br>Nairobi, Kenya.</p>
            </div>
            <div class="col-12 col-md-3 mbr-fonts-style display-7">
                <h5 class="pb-3">
                    Contacts
                </h5>
                <p class="mbr-text">Email: <br>info@blueheart-international.org<br> 
blueheart.africa@gmail.com<br>
<br>Phone:<br> +254 7 777 911 91</p>
            </div>
            <div class="col-12 col-md-3 mbr-fonts-style display-7">
                <h5 class="pb-3">
                    Links
                </h5>
                <p class="mbr-text">BlueHeart App&nbsp;<br><a class="text-primary" href="#bottom">Download for </a>Android&nbsp;<br><a class="text-primary" href="#bottom">Download for&nbsp;</a>Apple</p>
            </div>
        </div>
        <div class="footer-lower">
            <div class="media-container-row">
                <div class="col-sm-12">
                    <hr>
                </div>
            </div>
            <div class="media-container-row mbr-white">
                <div class="col-sm-6 copyright">
                    <p class="mbr-text mbr-fonts-style display-7">
                        © Copyright 2019 BlueHeart Intl.  |  Designed by the MobTribe
                    </p>
                </div>
                <div class="col-md-6">
                    <div class="social-list align-right">
                        <div class="soc-item">
                            <a href="#bottom" target="_blank">
                                <span class="mbr-iconfont mbr-iconfont-social socicon-twitter socicon"></span>
                            </a>
                        </div>
                        <div class="soc-item">
                            <a href="#bottom" target="_blank">
                                <span class="mbr-iconfont mbr-iconfont-social socicon-facebook socicon"></span>
                            </a>
                        </div>
                        <div class="soc-item">
                            <a href="#bottom" target="_blank">
                                <span class="mbr-iconfont mbr-iconfont-social socicon-youtube socicon"></span>
                            </a>
                        </div>
                        <div class="soc-item">
                            <a href="#bottom" target="_blank">
                                <span class="mbr-iconfont mbr-iconfont-social socicon-instagram socicon"></span>
                            </a>
                        </div>
                        
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


  <script src="assets/web/assets/jquery/jquery.min.js"></script>
  <script src="assets/popper/popper.min.js"></script>
  <script src="assets/tether/tether.min.js"></script>
  <script src="assets/bootstrap/js/bootstrap.min.js"></script>
  <script src="assets/dropdown/js/script.min.js"></script>
  <script src="assets/touchswipe/jquery.touch-swipe.min.js"></script>
  <script src="assets/viewportchecker/jquery.viewportchecker.js"></script>
  <script src="assets/parallax/jarallax.min.js"></script>
  <script src="assets/smoothscroll/smooth-scroll.js"></script>
  <script src="assets/theme/js/script.js"></script>
  <script src="assets/formoid/formoid.min.js"></script>

  <script  src="./script.js"></script>


  <script type="text/javascript">
        /*function validate() {
            var valid = true;

            $(".info").html("");
            var userName = document.forms["mailForm"]["userName"].value;
            var userEmail = document.forms["mailForm"]["userEmail"].value;
            var subject = document.forms["mailForm"]["subject"].value;
            var userMessage = document.forms["mailForm"]["userMessage"].value;
            
            if (userName == "") {
                $("#userName-info").html("(required)");
                $("#userName").css('background-color', '#FFFFDF');
                valid = false;
            }
            if (userEmail == "") {
                $("#userEmail-info").html("(required)");
                $("#userEmail").css('background-color', '#FFFFDF');
                valid = false;
            }
            if (!userEmail.match(/^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/))
            {
                $("#userEmail-info").html("(invalid)");
                $("#userEmail").css('background-color', '#FFFFDF');
                valid = false;
            }

            if (subject == "") {
                $("#subject-info").html("(required)");
                $("#subject").css('background-color', '#FFFFDF');
                valid = false;
            }
            if (userMessage == "") {
                $("#userMessage-info").html("(required)");
                $("#userMessage").css('background-color', '#FFFFDF');
                valid = false;
            }
            return valid;
        }*/
        
        function addMoreAttachment() {
            $(".attachment-row:last").clone().insertAfter(".attachment-row:last");
            $(".attachment-row:last").find("input").val("");
        }





        var currentTab = 0; // Current tab is set to be the first tab (0)
showTab(currentTab); // Display the current tab

function showTab(n) {
  // This function will display the specified tab of the form ...
  var x = document.getElementsByClassName("tab");
  x[n].style.display = "block";
  // ... and fix the Previous/Next buttons:
  if (n == 0) {
    document.getElementById("prevBtn").style.display = "none";
  } else {
    document.getElementById("prevBtn").style.display = "inline";
  }
  if (n == (x.length - 1)) {
    document.getElementById("nextBtn").innerHTML = "Submit";
  } else {
    document.getElementById("nextBtn").innerHTML = "Next";
  }
  // ... and run a function that displays the correct step indicator:
  fixStepIndicator(n)
}

function nextPrev(n) {
  // This function will figure out which tab to display
  var x = document.getElementsByClassName("tab");
  // Exit the function if any field in the current tab is invalid:
  if (n == 1 && !validateForm()) return false;
  // Hide the current tab:
  x[currentTab].style.display = "none";
  // Increase or decrease the current tab by 1:
  currentTab = currentTab + n;
  // if you have reached the end of the form... :
  if (currentTab >= x.length) {
    //...the form gets submitted:
    document.getElementById("regForm").submit();
    return false;
  }
  // Otherwise, display the correct tab:
  showTab(currentTab);
}

function validateForm() {
  // This function deals with validation of the form fields
  var x, y, i, valid = true;
  x = document.getElementsByClassName("tab");
  y = x[currentTab].getElementsByTagName("input");
  // A loop that checks every input field in the current tab:
  for (i = 0; i < y.length; i++) {
    // If a field is empty...
    if (y[i].value == "") {
      // add an "invalid" class to the field:
      y[i].className += " invalid";
      // and set the current valid status to false:
      valid = false;
    }
  }
  // If the valid status is true, mark the step as finished and valid:
  if (valid) {
    document.getElementsByClassName("step")[currentTab].className += " finish";
  }
  return valid; // return the valid status
}

function fixStepIndicator(n) {
  // This function removes the "active" class of all steps...
  var i, x = document.getElementsByClassName("step");
  for (i = 0; i < x.length; i++) {
    x[i].className = x[i].className.replace(" active", "");
  }
  //... and adds the "active" class to the current step:
  x[n].className += " active";
}
</script>

  <script src='https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js'></script>
<script src='https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js'></script>
  
  
  <input name="animation" type="hidden">
   <div id="scrollToTop" class="scrollToTop mbr-arrow-up"><a style="text-align: center;"><i class="mbr-arrow-up-icon mbr-arrow-up-icon-cm cm-icon cm-icon-smallarrow-up"></i></a></div>
  </body>
</html>
