<?php
require('phpmailer/class.phpmailer.php');

$content = $_POST["content"];
$phone = $_POST["phone"];
$userName = $_POST["userName"];
$userEmail = $_POST["userEmail"];
$subject = $_POST["subject"];

$mail = new PHPMailer();
$mail->IsSMTP();
$mail->SMTPDebug = 0;
$mail->SMTPAuth = TRUE;
$mail->SMTPSecure = "ssl";
//$mail->Port     = 587;
$mail->Port     = 465;  
$mail->Username = "info@egeza.co.ke";
$mail->Password = "tweecha1P.";
$mail->Host     = "mail.egeza.co.ke";
//$mail->Host     = "smtp.gmail.com";
$mail->Mailer   = "smtp";
$mail->SetFrom($_POST["userEmail"], $_POST["userName"]);
$mail->AddReplyTo($_POST["userEmail"], $_POST["phone"]);
$mail->AddAddress("info@egeza.co.ke");	
$mail->Subject = $_POST["subject"];
$mail->WordWrap   = 80;
//$mail->MsgHTML($_POST["content"]);
$mail->Body =   "<br>Name: " . $userName . "<br>Email: " . $userEmail . "<br>Telephone: " . $phone . "<br>Subject: " . $subject . "<br>Query: " . $content  ;



   

$mail->IsHTML(true);

if(!$mail->Send()) {
	echo "<p class='error'>Problem in Sending Mail.</p>";
} else {
	echo "<p class='success'>Contact Mail Sent.</p>";
}	
?>
